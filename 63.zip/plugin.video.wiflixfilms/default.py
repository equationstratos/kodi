import sys
import urllib.parse
import requests
import re
from bs4 import BeautifulSoup
import xbmcgui
import xbmcplugin
import xbmcaddon

# --- Configuration ---
HANDLE = int(sys.argv[1])
BASE_URL = "https://flemmix.rent"
USER_AGENT = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36'

# Menu principal avec les 22 catégories et icônes
CAT_DATA = [
    {"name": "[COLOR yellow]🔍 RECHERCHE[/COLOR]", "url": "search", "img": "https://i.ibb.co/L5k6YmX/search-icon.png"},
    {"name": "[COLOR white]🎬 Derniers Ajouts[/COLOR]", "url": f"{BASE_URL}/", "img": "https://i.ibb.co/3WkYvJt/latest-icon.png"},
    {"name": "[COLOR lightblue]📺 Séries[/COLOR]", "url": f"{BASE_URL}/serie-en-streaming/", "img": "https://i.ibb.co/y4pYv4J/tv-icon.png"},
    {"name": "[COLOR orange]🎭 Action[/COLOR]", "url": f"{BASE_URL}/film-en-streaming/action/", "img": "https://i.ibb.co/7XkYv8J/action-icon.png"},
    {"name": "[COLOR pink]💥 Animation[/COLOR]", "url": f"{BASE_URL}/film-en-streaming/animation/", "img": "https://i.ibb.co/5WkYv4J/animation-icon.png"},
    {"name": "[COLOR lightgreen]🥋 Arts Martiaux[/COLOR]", "url": f"{BASE_URL}/film-en-streaming/arts-martiaux/", "img": "https://i.ibb.co/5WkYv4J/arts-icon.png"},
    {"name": "[COLOR aqua]🧗 Aventure[/COLOR]", "url": f"{BASE_URL}/film-en-streaming/aventure/", "img": "https://i.ibb.co/3WkYvJt/adventure-icon.png"},
    {"name": "[COLOR khaki]📜 Biopic[/COLOR]", "url": f"{BASE_URL}/film-en-streaming/biopic/", "img": "https://i.ibb.co/L5k6YmX/bio-icon.png"},
    {"name": "[COLOR yellow]😂 Comédie[/COLOR]", "url": f"{BASE_URL}/film-en-streaming/comedie/", "img": "https://i.ibb.co/7XkYv8J/comedy-icon.png"},
    {"name": "[COLOR gold]🎭 Comédie Dramatique[/COLOR]", "url": f"{BASE_URL}/film-en-streaming/comedie-dramatique/", "img": "https://i.ibb.co/y4pYv4J/drama-icon.png"},
    {"name": "[COLOR red]🧛 Epouvante Horreur[/COLOR]", "url": f"{BASE_URL}/film-en-streaming/epouvante-horreur/", "img": "https://i.ibb.co/5WkYv4J/horror-icon.png"},
    {"name": "[COLOR grey]🏛️ Drame[/COLOR]", "url": f"{BASE_URL}/film-en-streaming/drame/", "img": "https://i.ibb.co/y4pYv4J/drama-icon.png"},
    {"name": "[COLOR white]📂 Documentaire[/COLOR]", "url": f"{BASE_URL}/film-en-streaming/documentaire/", "img": "https://i.ibb.co/L5k6YmX/doc-icon.png"},
    {"name": "[COLOR blue]🕶️ Espionnage[/COLOR]", "url": f"{BASE_URL}/film-en-streaming/espionnage/", "img": "https://i.ibb.co/9WkYv4J/thriller-icon.png"},
    {"name": "[COLOR lightblue]👨‍👩‍👧‍👦 Famille[/COLOR]", "url": f"{BASE_URL}/film-en-streaming/famille/", "img": "https://i.ibb.co/y4pYv4J/family-icon.png"},
    {"name": "[COLOR purple]🪄 Fantastique[/COLOR]", "url": f"{BASE_URL}/film-en-streaming/fantastique/", "img": "https://i.ibb.co/9WkYv4J/scifi-icon.png"},
    {"name": "[COLOR darkred]🎖️ Guerre[/COLOR]", "url": f"{BASE_URL}/film-en-streaming/guerre/", "img": "https://i.ibb.co/3WkYvJt/war-icon.png"},
    {"name": "[COLOR brown]🏰 Historique[/COLOR]", "url": f"{BASE_URL}/film-en-streaming/historique/", "img": "https://i.ibb.co/L5k6YmX/hist-icon.png"},
    {"name": "[COLOR violet]🎵 Musical[/COLOR]", "url": f"{BASE_URL}/film-en-streaming/musical/", "img": "https://i.ibb.co/y4pYv4J/music-icon.png"},
    {"name": "[COLOR darkblue]🚔 Policier[/COLOR]", "url": f"{BASE_URL}/film-en-streaming/policier/", "img": "https://i.ibb.co/9WkYv4J/police-icon.png"},
    {"name": "[COLOR lightpink]❤️ Romance[/COLOR]", "url": f"{BASE_URL}/film-en-streaming/romance/", "img": "https://i.ibb.co/y4pYv4J/romance-icon.png"},
    {"name": "[COLOR green]🚀 Science Fiction[/COLOR]", "url": f"{BASE_URL}/film-en-streaming/science-fiction/", "img": "https://i.ibb.co/9WkYv4J/scifi-icon.png"},
    {"name": "[COLOR white]🏟️ Spectacles[/COLOR]", "url": f"{BASE_URL}/film-en-streaming/spectacles/", "img": "https://i.ibb.co/3WkYv3t/show-icon.png"},
    {"name": "[COLOR darkorange]🕵️ Thriller[/COLOR]", "url": f"{BASE_URL}/film-en-streaming/thriller/", "img": "https://i.ibb.co/9WkYv4J/thriller-icon.png"},
    {"name": "[COLOR sandybrown]🤠 Western[/COLOR]", "url": f"{BASE_URL}/film-en-streaming/western/", "img": "https://i.ibb.co/3WkYvJt/western-icon.png"},
]

def get_html(url, post_data=None):
    try:
        headers = {'User-Agent': USER_AGENT, 'Referer': BASE_URL}
        if post_data:
            # Pour la recherche, on utilise un encodage classique de formulaire
            r = requests.post(url, headers=headers, data=post_data, timeout=15)
        else:
            r = requests.get(url, headers=headers, timeout=15)
        r.encoding = 'utf-8'
        return r.text
    except: return None

def main_menu():
    for item in CAT_DATA:
        li = xbmcgui.ListItem(label=item["name"])
        li.setArt({'icon': item["img"], 'thumb': item["img"], 'fanart': item["img"]})
        mode = 'search' if item["url"] == "search" else 'list_movies'
        query = urllib.parse.urlencode({'action': mode, 'url': item["url"]})
        xbmcplugin.addDirectoryItem(HANDLE, f"{sys.argv[0]}?{query}", li, isFolder=True)
    xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=False)

def list_movies(url, post_data=None):
    html = get_html(url, post_data)
    if not html: return
    soup = BeautifulSoup(html, 'html.parser')
    all_links = []
    seen_urls = set()
    
    # On cherche tous les liens films/séries
    for a in soup.find_all('a', href=True):
        href = a['href']
        if any(x in href for x in ['/film-en-streaming/', '/serie-en-streaming/', '/film-ancien/']) and href.endswith('.html'):
            full_url = href if href.startswith('http') else BASE_URL + href
            if full_url not in seen_urls:
                img = a.find('img') or (a.parent.find('img') if a.parent else None)
                raw_title = img.get('alt', '').strip() if img and img.get('alt') else a.get_text(strip=True)
                title = re.sub(r'(?i)flemmix|en streaming|vf|vostfr', '', raw_title).strip(' -–—:').strip()
                thumb = img.get('src', '') if img else ""
                if thumb and not thumb.startswith('http'): thumb = BASE_URL + thumb
                if len(title) < 2 or "telegram" in title.lower(): continue
                all_links.append({'title': title, 'url': full_url, 'thumb': thumb})
                seen_urls.add(full_url)

    # FILTRAGE INTELLIGENT
    is_search = post_data is not None # Si on a des data POST, c'est une recherche
    if is_search or len(all_links) < 30:
        final_list = all_links # En recherche, on prend tout !
    else:
        # En navigation normale, on garde le schéma 30/12
        final_list = all_links[30:-12] if len(all_links) > 42 else all_links[30:]

    for m in final_list:
        li = xbmcgui.ListItem(label=m['title'])
        li.setArt({'thumb': m['thumb'], 'icon': m['thumb'], 'fanart': m['thumb']})
        li.setInfo('video', {'title': m['title'], 'plot': "Cliquer pour voir le résumé complet."})
        q = urllib.parse.urlencode({'action': 'select_source', 'url': m['url'], 'title': m['title'], 'thumb': m['thumb']})
        xbmcplugin.addDirectoryItem(HANDLE, f"{sys.argv[0]}?{q}", li, isFolder=True)

    # PAGINATION (Seulement hors recherche)
    if not is_search:
        nav = soup.find('div', class_='navigation')
        next_url = None
        if nav:
            next_tag = nav.find('a', string=re.compile(r'Suivant|>>|Next')) or nav.find('a', class_='pnext')
            if next_tag: next_url = next_tag['href']
        
        if not next_url:
            if "/page/" in url:
                match = re.search(r'/page/(\d+)/', url)
                if match:
                    curr = int(match.group(1))
                    next_url = url.replace(f'/page/{curr}/', f'/page/{curr+1}/')
            else:
                next_url = url.rstrip('/') + '/page/2/'

        if next_url:
            if not next_url.startswith('http'): next_url = BASE_URL + next_url
            li_next = xbmcgui.ListItem(label="[COLOR green]➡ PAGE SUIVANTE[/COLOR]")
            q_next = urllib.parse.urlencode({'action': 'list_movies', 'url': next_url})
            xbmcplugin.addDirectoryItem(HANDLE, f"{sys.argv[0]}?{q_next}", li_next, isFolder=True)

    xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=False)

def select_source(url, title, thumb):
    html = get_html(url)
    if not html: return
    soup = BeautifulSoup(html, 'html.parser')
    
    # Récupération du synopsis complet sur la fiche du film
    plot = "Résumé indisponible."
    story_div = soup.find('div', class_='rest-text') or soup.find('div', class_='story') or soup.find('div', id='news-id-content')
    if story_div: plot = story_div.get_text(strip=True)

    matches = re.findall(r"loadVideo\('(.+?)'\)", html)
    for v_url in set(matches):
        if v_url.startswith('//'): v_url = "https:" + v_url
        srv = "Lecteur"
        if "voe" in v_url.lower(): srv = "Voe"
        elif "uqload" in v_url.lower(): srv = "Uqload"
        elif "vidmoly" in v_url.lower(): srv = "Vidmoly"
        
        li = xbmcgui.ListItem(label=f"▶ {srv}")
        li.setArt({'thumb': thumb, 'icon': thumb})
        li.setProperty('IsPlayable', 'true')
        li.setInfo('video', {'title': title, 'plot': plot})
        q = urllib.parse.urlencode({'action': 'play', 'url': v_url})
        xbmcplugin.addDirectoryItem(HANDLE, f"{sys.argv[0]}?{q}", li, isFolder=False)
    xbmcplugin.endOfDirectory(HANDLE)

def play_video(url):
    try:
        import resolveurl
        res = resolveurl.resolve(url)
        if res: xbmcplugin.setResolvedUrl(HANDLE, True, xbmcgui.ListItem(path=res))
    except: pass

def search():
    kb = xbmcgui.Keyboard("", "Rechercher un film ou une série")
    kb.doModal()
    if kb.isConfirmed() and kb.getText():
        search_text = kb.getText()
        # On utilise le point d'entrée de recherche DLE
        search_url = f"{BASE_URL}/index.php?do=search"
        data = {
            'do': 'search',
            'subaction': 'search',
            'story': search_text,
            'user_hash': '' # Parfois nécessaire, on laisse vide pour tester
        }
        list_movies(search_url, data)

# --- Router ---
params = dict(urllib.parse.parse_qsl(sys.argv[2][1:]))
action = params.get('action')
if not action: main_menu()
elif action == 'list_movies': list_movies(params.get('url'))
elif action == 'select_source': select_source(params.get('url'), params.get('title'), params.get('thumb'))
elif action == 'play': play_video(params.get('url'))
elif action == 'search': search()
